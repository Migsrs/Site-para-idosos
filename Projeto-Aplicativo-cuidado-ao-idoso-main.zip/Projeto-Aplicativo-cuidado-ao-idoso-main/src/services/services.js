// This file manages the services offered on the website. It exports functions to add new services, retrieve available services, and handle service-related operations.

let services = [];

function addService(service) {
    services.push(service);
}

function getServices() {
    return services;
}

function purchaseService(serviceId) {
    const serviceIndex = services.findIndex(service => service.id === serviceId);
    if (serviceIndex !== -1) {
        // Logic for processing the purchase can be added here
        return services[serviceIndex];
    }
    return null;
}

export { addService, getServices, purchaseService };