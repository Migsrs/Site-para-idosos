// This file manages user-related functionalities. It exports functions for user registration, login, and managing user profiles.

const users = [];

// Function to register a new user
export function registerUser(username, password) {
    const user = { username, password };
    users.push(user);
    return user;
}

// Function to login a user
export function loginUser(username, password) {
    const user = users.find(user => user.username === username && user.password === password);
    return user ? true : false;
}

// Function to get user profile
export function getUserProfile(username) {
    const user = users.find(user => user.username === username);
    return user ? { username: user.username } : null;
}

// Function to update user profile
export function updateUserProfile(username, newUsername, newPassword) {
    const user = users.find(user => user.username === username);
    if (user) {
        user.username = newUsername;
        user.password = newPassword;
        return user;
    }
    return null;
}