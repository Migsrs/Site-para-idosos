// This file contains the main JavaScript functionality for the elderly services website.
// It includes event listeners for adding services and processing purchases, with localStorage persistence.

document.addEventListener('DOMContentLoaded', () => {
    const serviceForm = document.getElementById('service-form');
    const serviceList = document.getElementById('service-list');

    // Load services from localStorage or initialize as empty array
    function getServices() {
        const services = localStorage.getItem('services');
        return services ? JSON.parse(services) : [];
    }

    // Save services to localStorage
    function saveServices(services) {
        localStorage.setItem('services', JSON.stringify(services));
    }

    // Render all services in the list
    function renderServices() {
        if (!serviceList) return;
        serviceList.innerHTML = '';
        const services = getServices();
        services.forEach((service, idx) => {
            const serviceItem = document.createElement('li');
            serviceItem.textContent = `${service.name} - $${service.price}`;
            const purchaseButton = document.createElement('button');
            purchaseButton.textContent = 'Purchase';
            purchaseButton.addEventListener('click', () => {
                alert(`You have purchased: ${service.name} for $${service.price}`);
            });
            serviceItem.appendChild(purchaseButton);
            serviceList.appendChild(serviceItem);
        });
    }

    // Add a new service and update storage
    function addService(name, price) {
        const services = getServices();
        services.push({ name, price });
        saveServices(services);
        renderServices();
    }

    // Handle form submission
    if (serviceForm) {
        serviceForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const serviceName = document.getElementById('service-name').value;
            const servicePrice = document.getElementById('service-price').value;

            if (serviceName && servicePrice) {
                addService(serviceName, servicePrice);
                serviceForm.reset();
            } else {
                alert('Please fill in all fields.');
            }
        });
    }

    // Initial render
    renderServices();
});