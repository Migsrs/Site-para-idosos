document.addEventListener('DOMContentLoaded', () => {
    // Demo user (username: user, password: pass)
    if (!localStorage.getItem('users')) {
        localStorage.setItem('users', JSON.stringify([{username: 'user', password: 'pass'}]));
    }

    // Login logic
    const loginForm = document.getElementById('login-form');
    const loginMsg = document.getElementById('login-message');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const username = document.getElementById('login-username').value;
            const password = document.getElementById('login-password').value;
            const users = JSON.parse(localStorage.getItem('users')) || [];
            const found = users.find(u => u.username === username && u.password === password);
            if (found) {
                localStorage.setItem('loggedInUser', username);
                window.location.href = 'index.html';
            } else {
                loginMsg.textContent = 'Invalid username or password.';
            }
        });
    }

    // Registration logic
    const registerForm = document.getElementById('register-form');
    const registerMsg = document.getElementById('register-message');
    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const username = document.getElementById('register-username').value;
            const password = document.getElementById('register-password').value;
            let users = JSON.parse(localStorage.getItem('users')) || [];
            if (users.find(u => u.username === username)) {
                registerMsg.textContent = 'Username already exists.';
                return;
            }
            users.push({username, password});
            localStorage.setItem('users', JSON.stringify(users));
            registerMsg.textContent = 'Registration successful! You can now log in.';
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 1200);
        });
    }
});